import { Component, OnInit } from "@angular/core";
import { AuthService } from "src/app/Services/auth.service";
import { Observable } from "rxjs/internal/Observable";

@Component({
  selector: "app-header",
  templateUrl: "./header.component.html",
  styles: ["./header.component.scss"]
})
export class HeaderComponent implements OnInit {
  constructor(public auth: AuthService) {}
  public isLogin: boolean = false;

  ngOnInit() {
    this.isLogin = this.auth.isAuthenticated();     
  }
}
