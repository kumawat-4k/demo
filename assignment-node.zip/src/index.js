const mongoose = require('mongoose');
const app = require('express')();
const bodyParser = require('body-parser');
require('dotenv').config();
const {__} = require('./util/common');
const {Response} = require('./util/http-status-codes');
global.vrules = require('./util/validation_rules.js').rules;
global.Validator = require('validatorjs');
global._ = require('lodash');
global.ObjectId = require('mongodb').ObjectID;

//region Connection
mongoose.connect(process.env.MONGO_URI, {useNewUrlParser: true});
mongoose.set('debug', process.env.NODE_ENV === 'development');
const findOneOrFail = function (schema) {
    schema.statics.findOneOrFail = function () {
        const self = this;
        const findArguments = arguments;
        return new Promise(async function (resolve, reject) {
            const data = await self.findOne(findArguments[0]);
            if (!data) reject(new Error('EntityNotFound'));
            else resolve(data);
        })
    }
};
mongoose.plugin(findOneOrFail);
//endregion Connection

app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization, Accept-Language, Pragma, Cache-Control, Expires, If-Modified-Since");
    res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, DELETE");
    res.header("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
    res.header("Pragma", "no-cache"); // HTTP 1.0.
    res.header("Expires", "0"); // Proxies.
    next();
});
app.use(bodyParser.json({limit: '100mb'}));
app.use((req, res, next) => {
    //console.log("data=========>", req.body);
    __.setLanguage(req.headers['accept-language']);
    next();
});
app.use((req, res, next) => {
    res.locals.site_title = process.env.SITE_TITLE;
    for(const method in Response) {
        if(Response.hasOwnProperty(method))
            res[method] = Response[method];
    } next();
});
app.use('/', require('./routes'));
app.use((err, req, res, next) => {

    console.error(err);

    if (res.headersSent) {
        return next(err);
    }

    if (err.message === 'EntityNotFound') {
        return res.status(404).send({
            success: false,
            data: [],
            message: 'Record not found'
        });
    }

    return res.status(err.status || 500).send({
        success: false,
        data: [],
        message: 'An error occurred'
    });

});

const port = process.env.PORT || 15000;
app.listen(port, function () {
    console.info(`Server Started on port ${port}`);
});
