const { User } = require('../models/User');
const { __, sendMail, randomString} = require('../util/common');
const { to } = require('await-to-js');
const { signToken } = require('../util/auth');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

const AuthController = {

    /**
     * Business can log into Application, Traveler can't log into Vendor Panel
     */
    login: async function (req, res) {
        const { email, password } = req.body;
        const conditions = {
            email: email.trim().toLowerCase(),
        };

        const [err, user] = await to(User.findOne(conditions).sort({emailVerified: -1}));
        if (err || !user) return res.notFound(null, __('INVALID_CREDENTIALS'));

        if (!user.comparePassword(password)) {
            return res.notFound(null, __('INVALID_CREDENTIALS'));
        }

        if (!user.emailVerified) {
            return res.badRequest(null, __('VERIFY_EMAIL_TO_CONTINUE'));
        }
        if (user.status == false) {
            return res.badRequest(null, __('ACCOUNT_INACTIVE'));
        }

        const token = signToken(user);
        
        const userJson = user.toJSON();
        delete userJson.password;
        delete userJson.resetToken;
        delete userJson.resetTokenExpiry;
        delete userJson.__v;

        return res.success({
            token,
            user: userJson
        }, __('LOGIN_SUCCESS'));

    },

    signup: async function (req, res, next) {
        const { firstName, lastName, email, password } = req.body;
        let conditions = [
            { email: email.trim().toLowerCase() },
        ];
        const existingUser = await User.findOne({$or: conditions,}).sort({emailVerified: -1});
        if (existingUser && existingUser.emailVerified) {
            if (existingUser.email.match(new RegExp(`^${conditions[0].email}$`, 'i'))) {
                return res.badRequest(null, __('EMAIL_EXISTS'));
            } 
        }

        const user = existingUser || new User();
        user.firstName = firstName;
        user.lastName = lastName;
        user.email = email;
        user.password = password;
        user.fullName = firstName + ' ' + lastName;
        user.resetToken = randomString(40);
        user.created = new Date();

        if (existingUser) {
            bcrypt.genSalt(parseInt(process.env.BCRYPT_ITERATIONS, 10) || 10, function (err, salt) {
                if (err) return next(err);
                bcrypt.hash(user.password, salt, function (err, hash) {
                    if (err) return next(err);
                    user.password = hash;
                });
            });
        }

        const [err, saved] = await to(user.save());
        if(err && 'email' in err) return res.badRequest(null, __('EMAIL_EXISTS'));
        if (err) return res.serverError(null, __('GENERAL_ERROR'), err);

        res.success(true, __('SIGNUP_SUCCESS'));

        sendMail('website-verify-email', 'Verify your email address', user.email, {
            verification_link: process.env.SITE_URL + 'auth/verify-account?token=' + encodeURI(user.resetToken)
        }).catch(err => { console.log(err) });

    },

    isUnique: async function (req, res, next) {
        const { email } = req.query;
        try {

            let count = 99; //Any non-zero value
            if (email) {
                count = await User.count({
                    email: email.trim().toLowerCase(),
                    emailVerified: true,
                });
            } 
            res.success(count === 0, count === 0 ? __('UNIQUE') : __('ALREADY_EXISTS'));

        } catch (e) {
            res.serverError(null, __('GENERAL_ERROR'), e);
        }

    },

    verifyEmail: async function (req, res, next) {
        const { token } = req.body;
        if (!token) {
            return res.success(false, __('VERIFICATION_FAILED'));
        }
        const [err, saved] = await to(User.findOneAndUpdate({ resetToken: token }, {
            $set: {
                status: true,
                emailVerified: true,
                resetToken: null,
            }
        }));

        if (err || !saved) {
            return res.success(false, __('VERIFICATION_FAILED'));
        }
        return res.success(true, __('VERIFICATION_PASSED'));

    }  
};

module.exports = AuthController;