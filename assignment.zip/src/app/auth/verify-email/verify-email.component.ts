import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/Services/auth.service';

@Component({
  selector: 'app-verify-email',
  templateUrl: './verify-email.component.html',
  styles: []
})
export class VerifyEmailComponent implements OnInit {

  constructor(private route: ActivatedRoute, private auth: AuthService, private router: Router) { }

  verification = 'pending';

  ngOnInit() {
    const token = this.route.snapshot.queryParams['token'];
    this.auth.verifyEmail(token).subscribe(response => {
      if (response.data === true) {
        this.verification = 'success';
        setTimeout(() => this.router.navigate(['/auth/sign-in']), 4000);
      } else {
        this.verification = 'error';
      }
    });
  }

}
