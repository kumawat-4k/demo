const rules = {};

rules.login = {
    email: 'required|email',
    password: 'required',
};

rules.signup = {
    firstName: 'required',
    lastName: 'required',
    email: 'required|email',
    password: 'required|min:8',
};

module.exports.rules = rules;
