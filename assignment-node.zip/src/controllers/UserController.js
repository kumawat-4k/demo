const { User } = require("../models/User");
const { Product } = require("../models/Product");
const { __, generateOtp, sendMail } = require("../util/common");
const { to } = require("await-to-js");

const UserController = {
  profile: async function(req, res, next) {
    const user = req.user;

    const userJson = user.toJSON();
    delete userJson.password;
    delete userJson.resetToken;
    delete userJson.resetTokenExpiry;

    res.success(userJson);
  },

  /**
   * @todo Update verification status
   */

  getProduct: async function(req, res) {
    let data = await Product.find();
    res.success(data);
  },

  getMyProduct: async function(req, res) {
    let data = await User.findOne({ _id: req.user._id })
      .populate("products")
      .exec();
    res.success(data.products);
  },

  addProduct: async function(req, res) {
    const params = _.extend(req.query || {}, req.params || {}, req.body || {});
    const data = await User.findOne({ _id: req.user._id });
    let products = [];
    params.products.forEach(item => {
      let isExist = data.products.findIndex(value=> value ==item._id);
      if (item.selected && isExist  == -1) {
        products.push(ObjectId(item._id));
      }
    });
    await data.update(
      {
        $push: {
          products: { $each: products }
        }
      }
    );
    res.success(data);
  }
};

module.exports = UserController;