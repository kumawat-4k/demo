import { Injectable } from '@angular/core';
import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { AuthService } from 'src/app/Services/auth.service';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import {environment} from '../../environments/environment'


@Injectable()
export class TokenInterceptor implements HttpInterceptor {

  constructor( private auth: AuthService ) {
  }

  intercept( req: HttpRequest<any>, next: HttpHandler ): Observable<HttpEvent<any>> {

    if (!req.url.startsWith(environment.apiUrl)) {
      return next.handle(req);
    }

    const token = this.auth.getToken();
    if (token) {
      req = req.clone({
        setHeaders: {
          Authorization: token,
          'Content-Type': 'application/json'
        }
      });
    }
    return next.handle(req).pipe(tap(( event: HttpEvent<any> ) => {

    }, ( err: any ) => {
      if (err instanceof HttpErrorResponse) {
        if (err.status === 401) {
          this.auth.logout();
        }
      }
    }));

  }

}
