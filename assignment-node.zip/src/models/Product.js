const mongoose = require("mongoose"),
  Schema = mongoose.Schema;

const ProductSchema = new Schema({
  name: { type: String, required: false },
  description: { type: String, required: false }  
});

module.exports.Product = mongoose.model("Product", ProductSchema, 'products');
