const mongoose = require('mongoose'),
    bcrypt = require('bcrypt'),
    Schema = mongoose.Schema;

/**
 * User Schema
 * @type Schema<User>
 */
const UserSchema = new Schema({
    firstName: {
        type: String,
        trim: true,
        required: true
    },
    fullName: {
        type: String,
        required: true
    },
    lastName: {
        type: String,
        trim: true,
    },
    email: {
        type: String,
        lowercase: true,
        trim: true,
        required: true,
    },
    password: {
        type: String,
        required: true,
    },
    emailVerified: {
        type:Boolean
    },
    resetToken: {
        type: String
    },
    resetTokenExpiry: {
        type:String
    },
    products: [{
        type: Schema.Types.Mixed,
        ref: 'Product'        
    }]
}, {
    timestamps: {
        createdAt: 'created',
        updatedAt: 'updated'
    },
    id: false,
    toJSON: {
        getters: true,
        virtuals: true
    },
    toObject: {
        getters: true,
        virtuals: true
    }
});

UserSchema.index({email: 1, emailVerified: 1}, {unique: true, dropDups: true});

//http://devsmash.com/blog/password-authentication-with-mongoose-and-bcrypt
UserSchema.pre('save', function (next) {

    var user = this;

    // only hash the password if it has been modified (or is new)
    if (!user.isModified('password')) return next();

    // generate a salt
    bcrypt.genSalt(parseInt(process.env.BCRYPT_ITERATIONS, 10) || 10, function (err, salt) {
        if (err) return next(err);

        // hash the password using our new salt
        bcrypt.hash(user.password, salt, function (err, hash) {
            if (err) return next(err);

            // override the cleartext password with the hashed one
            user.password = hash;
            next();
        });
    });
});

UserSchema.virtual('name').get(function () {
    return this.firstName + " " + this.lastName;
});

UserSchema.methods.comparePassword = function (password) {
    return bcrypt.compareSync(password, this.password);
};


module.exports.User = mongoose.model('User', UserSchema);