# TripMood App and Website Webservices
        
Steps to run this project:

1. Run `npm i` or `yarn install` command
2. Rename `.env.example` to `.env` and configure environment variables inside it
3. Run `npm start` or `yarn start` command
4. During development, use `npm run watch` or `yarn watch` command
