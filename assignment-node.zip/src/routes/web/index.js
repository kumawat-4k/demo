const express = require('express');
const router = express.Router();

router.use('/auth', require('./AuthRoutes'));
router.use('/user', require('./UserRoutes'));

module.exports = router;
