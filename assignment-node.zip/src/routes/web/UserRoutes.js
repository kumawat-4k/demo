const express = require('express');
const router = express.Router();
const UserController = require('../../controllers/UserController');
const {verifyToken} = require('../../util/auth');
const {validate} = require('../../util/common');

router.get('/get-product', verifyToken, UserController.getProduct);

router.get('/get-my-product', verifyToken, UserController.getMyProduct);

router.post('/add-product', verifyToken, UserController.addProduct);


module.exports = router;