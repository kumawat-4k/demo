const express = require('express');
const router = express.Router();
const AuthController = require('../../controllers/AuthController');
const {validate} = require('../../util/common');

router.post('/login', validate(vrules.login), AuthController.login);

router.post('/signup', validate(vrules.signup), AuthController.signup);

router.post('/verify-email', AuthController.verifyEmail);

router.get('/is-unique', AuthController.isUnique);

module.exports = router;