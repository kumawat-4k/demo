import { Component, OnInit } from "@angular/core";
import { finalize } from "rxjs/operators";
import { ToastrService } from "ngx-toastr";
import { UserService } from "src/app/Services/user.service";
import { FormArray, FormBuilder, Validators } from "@angular/forms";

@Component({
  selector: "app-product",
  templateUrl: "./product.component.html",
  styleUrls: ["./product.component.scss"]
})
export class ProductComponent implements OnInit {
  constructor(
    private toastr: ToastrService,
    private userService: UserService,
    private fb: FormBuilder
  ) {}
  submitAttempted = false;
  isBusy = false;
  productList: any[];
  selectedTagCount = 0;

  private validateTagCount = () =>
    new Promise(resolve =>
      setTimeout(() =>
        resolve(this.selectedTagCount > 0 ? null : { count: true })
      )
    );

  form = this.fb.group({
    products: this.fb.array([], [])
  });

  get products() {
    return this.form.get("products") as FormArray;
  }

  ngOnInit() {
    this.ProductList();
  }

  addProduct(productId) {
    this.userService
      .addProduct(productId)
      .pipe(finalize(() => (this.isBusy = false)))
      .subscribe(response => {
        if (response.success === true) {
          this.toastr.success("Product Add Successfully in Your List");
        }
      });
  }

  onSubmit() {
    if (this.form.valid) {
      this.userService
        .addProduct(this.form.value)
        .pipe(finalize(() => (this.isBusy = false)))
        .subscribe(response => {
          if (response.success === true) {
            this.toastr.success("Product Add Successfully in Your List");
          }
        });
    }
  }

  ProductList() {
    this.userService
      .getProduct()
      .pipe(finalize(() => (this.isBusy = false)))
      .subscribe(response => {
        if (response.success === true) {
          this.productList = response.data;
          this.productList.forEach(item => {
            this.products.push(
              this.fb.group({
                _id: [item._id],
                name: [item.name],
                selected: false
              })
            );
          });
        }
      });
  }
}
