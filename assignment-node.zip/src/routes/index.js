const express = require('express');
const router = express.Router();


router.use('/web', (req, res, next) => { req.isWeb = true; next() }, require('./web'));

module.exports = router;