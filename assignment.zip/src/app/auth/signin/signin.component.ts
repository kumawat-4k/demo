import { Component, OnInit } from "@angular/core";
import { FormBuilder, Validators, FormArray, FormGroup } from "@angular/forms";
import { finalize } from "rxjs/operators";
import { CustomValidators } from "src/app/validators/CustomValidators";
import { CustomAsyncValidators } from "src/app/validators/CustomAsyncValidators";
import { AuthService } from "src/app/Services/auth.service";
import { ToastrService } from "ngx-toastr";
import { Router } from "@angular/router";
import { StorageService } from "src/app/Services/storage.service";
import { UserService } from "src/app/Services/user.service";
import { HttpErrorResponse } from "@angular/common/http";

@Component({
  selector: "app-signin",
  templateUrl: "./signin.component.html",
  styleUrls: ["./signin.component.scss"]
})
export class SigninComponent implements OnInit {
  constructor(
    private fb: FormBuilder,
    private asyncValidators: CustomAsyncValidators,
    private auth: AuthService,
    private toastr: ToastrService,
    private router: Router,
    private storage: StorageService,
    private userService: UserService
  ) {}

  submitAttempted = false;
  isBusy = false;

  form = this.fb.group({
    email: ["", [Validators.required, CustomValidators.email]],
    password: ["", Validators.required]
  });

  onSubmit() {
    if (this.isBusy) {
      return;
    }

    this.submitAttempted = true;
    if (!this.form.valid) {
      return false;
    }

    this.isBusy = true;
    this.auth
      .authenticate(this.form.value)
      .pipe(finalize(() => (this.isBusy = false)))
      .subscribe(
        response => {
          if (response.success === true) {
            this.toastr.success("Login Success");
            this.auth.setToken(response.data.token);
            this.userService.setCurrentUser(response.data.user);
            this.router.navigate([""]);

            setTimeout(() => {
              location.reload(true);
            }, 500);
          }
        },
        err => {
          if (err instanceof HttpErrorResponse) {
            if (err.status === 404) {
              this.form.markAsPristine();
            }
          }
        }
      );
  }
  ngOnInit() {}
}
