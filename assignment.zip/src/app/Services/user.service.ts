import { Injectable } from "@angular/core";
import { IResponse } from "src/app/models/response.model";
import { User } from "src/app/models/user.model";
import { StorageService } from "./storage.service";
import { environment } from "../../environments/environment";
import { Observable } from "rxjs";
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: "root"
})
export class UserService {
  constructor(private storage: StorageService, private http: HttpClient) {}

  getCurrentUser(): User {
    return this.storage.getItem<User>("user");
  }

  setCurrentUser(user: User) {
    this.storage.setItem("user", user);
  }

  removeCurrentUser() {
    this.storage.removeItem("user");
  }

  verifyEmailOtp(email: string, otp: string): Observable<IResponse<any>> {
    return this.http.post<IResponse<any>>(
      `${environment.apiUrl}/user/verify-email-otp`,
      { email, otp }
    );
  }

  getProduct(): Observable<IResponse<any[]>> {
    return this.http.get<IResponse<any[]>>(
      `${environment.apiUrl}/user/get-product`
    );
  }

  getMyProduct(): Observable<IResponse<any[]>> {
    return this.http.get<IResponse<any[]>>(
      `${environment.apiUrl}/user/get-my-product`
    );
  }

  addProduct(products: any): Observable<IResponse<any>> {
    return this.http.post<IResponse<any>>(
      `${environment.apiUrl}/user/add-product`,
       products 
    );
  }
}
