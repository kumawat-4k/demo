import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { AuthService } from '../Services/auth.service';

@Injectable({
    providedIn: 'root'
})
export class CustomAsyncValidators {

    private emailDebouncer: any;
    private usernameDebouncer: any;

    constructor( private auth: AuthService ) {
        this.isUniqueEmail = this.isUniqueEmail.bind(this);
    }

    public isUniqueEmail( control: FormControl ) {
        clearTimeout(this.emailDebouncer);
        return new Promise(resolve => {
            this.emailDebouncer = setTimeout(() => {
                this.auth.verifyUnique('email', control.value).subscribe(response => {
                    if (response.data === true) {
                        resolve(null);
                    } else {
                        resolve({isUniqueEmail: true});
                    }
                }, err => resolve({isUniqueEmail: true}));
            }, 800);
        });
    }
}
