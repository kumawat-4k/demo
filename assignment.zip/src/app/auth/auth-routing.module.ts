import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { SigninComponent } from "./signin/signin.component";
import { SignupComponent } from "./signup/signup.component";
import { VerifyEmailComponent } from "src/app/auth/verify-email/verify-email.component";
import { LoginGuard } from "../guards/login.guard";

const routes: Routes = [
  {
    path: "",
    redirectTo: "sign-in"
  },
  {
    path: "sign-up",
    canActivate: [LoginGuard],
    component: SignupComponent
  },
  {
    path: "sign-in",
    canActivate: [LoginGuard],
    component: SigninComponent
  },
  {
    path: 'verify-account',
    canActivate: [LoginGuard],
    component: VerifyEmailComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule {}
