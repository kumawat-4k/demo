import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ValidationComponent } from './validation/validation.component';
import { NgbDropdownModule, NgbProgressbarModule, NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClient } from '@angular/common/http';
import { RouterModule } from '@angular/router';

export function HttpLoaderFactory(http: HttpClient) {
  return;
  //return new TranslateHttpLoader(http, 'assets/i18n/', '.json');
}

const COMPONENTS = [
  ValidationComponent,
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    NgbTooltipModule,
    NgbDropdownModule,
    NgbProgressbarModule,
  ],
  declarations: [...COMPONENTS],
  exports: [...COMPONENTS],
})
export class UtilModule {}
