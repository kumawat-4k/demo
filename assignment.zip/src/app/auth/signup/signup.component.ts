import { Component, OnInit } from "@angular/core";
import { FormBuilder, Validators, FormArray, FormGroup } from "@angular/forms";
import { finalize } from "rxjs/operators";
import { CustomValidators } from "src/app/validators/CustomValidators";
import { CustomAsyncValidators } from "src/app/validators/CustomAsyncValidators";
import { AuthService } from "src/app/Services/auth.service";
import { ToastrService } from 'ngx-toastr';
import { Router } from "@angular/router";

@Component({
  selector: "app-signup",
  templateUrl: "./signup.component.html",
  styleUrls: ["./signup.component.scss"]
})
export class SignupComponent implements OnInit {
  constructor(
    private fb: FormBuilder,
    private asyncValidators: CustomAsyncValidators,
    private auth: AuthService,
    private toastr: ToastrService,
    private router: Router
  ) {}
  submitAttempted = false;
  isBusy = false;

  form = this.fb.group(
    {
      firstName: ["", Validators.required],
      lastName: ["", Validators.required],
      email: ["", [Validators.required, CustomValidators.email]],
      password: [
        "",
        [
          Validators.required,
          Validators.pattern(/^(?=(.*[a-z])+)(?=(.*[A-Z])+)(?=(.*[!@#$%^&*()<>,.?|])+).{6,}$/)
        ]
      ],
      confirmPassword: ["", Validators.required]
    },
    { validator: CustomValidators.matchPassword }
  );

  onSubmit() {
    if (this.isBusy) {
      return;
    }

    this.submitAttempted = true;
    if (!this.form.valid) {
      return false;
    }

    this.isBusy = true;
    this.auth
      .signup(this.form.value)
      .pipe(finalize(() => (this.isBusy = false)))
      .subscribe(response => {
        if (response.success === true) {
          this.toastr.success(response.message);
          this.router.navigate(["/auth/sign-in"]);
        }
      });
  }
  ngOnInit() {}
}
