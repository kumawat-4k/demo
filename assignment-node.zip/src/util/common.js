const Validator = require('validatorjs');
const nodemailer = require('nodemailer');
const {EmailTemplate} = require('email-templates');
const path = require('path');
const uuid = require('uuid/v4');
const languages = {
    en: require('../locales/en.json'),
    es: require('../locales/es.json'),
};

const extend = function (obj, args) {
    if (Array.isArray(args) || (args !== null && typeof args === 'object')) {
        for (i in args) {
            this[i] = args[i];
        }
    }
    return obj;
};

const __ = (key, ...params) => {
    const l10n = languages[this.language] || languages['en'];
    let message = l10n[key] || key;
    let position = 0;
    params.forEach(param => {
        message = message.replace(new RegExp('\\{' + position + '}'), param);
        position++;
    });
    return message;
};

__.setLanguage = language => this.language = language;

const generateOtp = (length = 4) => {

    if (process.env.NODE_ENV === 'development') {
        return '1234';
    }

    let otp = Math.floor(Math.random() * (10 ** length)).toString();
    if (otp.length < length) {
        otp = '0'.repeat(length - otp.length) + otp;
    }
    return otp;
};

const randomString = (len, charSet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789') => {
    let randomString = '';
    for (let i = 0; i < len; i++) {
        const randomPos = Math.floor(Math.random() * charSet.length);
        randomString += charSet.substring(randomPos, randomPos + 1);
    }
    return randomString;
};

/**
 * Takes first error from extracted Errors
 * @see extractErrors
 * @returns {string}
 */
const firstError = errors => errors[Object.keys(errors)[0]][0];

/**
 * @param {string} uri
 * @returns {{type: string, data: string}}
 */
const parseDataUri = (uri) => {
    const [, type = '', data = ''] = uri.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/) || [];
    return {type, data};
};

const validate = rulesObj => (req, res, next) => {
    // Validating Input
    var validation = new Validator(req.body, rulesObj);
    if (validation.fails()) {
        var errorObj = validation.errors.all();
        res.status(400);
        res.json({
            success: false,
            data: null,
            message: errorObj[Object.keys(errorObj)[0]][0]
        });
        return res;
    } else {
        return next();
    }
};

const sendMail = function (template, subject, email, emailData) {
    template = new EmailTemplate(path.join(__dirname, '../templates/', template));
    const transport = this.transport;

    var locals = {custom: emailData};
    locals.site_title = process.env.SITE_TITLE || "";
    locals.email_logo = process.env.LOGO_PATH || "";

    return new Promise((resolve, reject) => {
        template.render(locals, function (err, results) {
            if (err) {
                return reject(err);
            } else {
                transport.sendMail({
                    from: process.env.FROM_MAIL,
                    to: email,
                    subject: subject,
                    html: results.html,
                    text: results.text
                }, function (err) {
                    if (err) {
                        return reject(err);
                    } else {
                        return resolve(true);
                    }
                });
            }
        });
    })

};

extend(sendMail, {
    transport: nodemailer.createTransport({
        pool: true,
        host: process.env.SMTP_HOST,
        port: process.env.SMTP_PORT,
        secure: process.env.SMTP_SECURE.toLowerCase() === 'true',
        service: process.env.SMTP_SERVICE,
        auth: {
            user: process.env.SMTP_USERNAME,
            pass: process.env.SMTP_PASSWORD,
        }
    })
});

module.exports = {
    __,
    generateOtp,
    randomString,
    firstError,
    parseDataUri,
    validate,
    sendMail   
};

