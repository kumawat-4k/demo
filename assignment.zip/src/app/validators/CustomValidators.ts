import { AbstractControl } from '@angular/forms';

export class CustomValidators {
  static matchPassword(form: AbstractControl) {
    const password = form.get('password').value;
    const confirmPassword = form.get('confirmPassword').value;

    if (password !== confirmPassword) {
      form.get('confirmPassword').setErrors({ matchPassword: true });
    } else {
      const control = form.get('confirmPassword');
      let errors = control.errors;
      if (errors) {
        delete errors.matchPassword;
      }

      if (!errors || !Object.keys(errors).length) {
        errors = null;
      }

      control.setErrors(errors);
    }

    return null;
  }

  static match(thisField: string, matchWithField: string) {
    return function(form: AbstractControl) {
      const value1 = form.get(thisField).value;
      const value2 = form.get(matchWithField).value;

      if (value1 !== value2) {
        form.get(thisField).setErrors({ match: true });
      } else {
        const control = form.get(thisField);
        let errors = control.errors;
        if (errors) {
          delete errors.match;
        }

        if (!errors || !Object.keys(errors).length) {
          errors = null;
        }

        control.setErrors(errors);
      }

      return null;
    };
  }

  static phone(control: AbstractControl) {
    if (!control.value) {
      return null;
    }
    if (!control.value.match(/^[\d]{9,14}$/)) {
      return { phone: true };
    }
    return null;
  }

  static url(control: AbstractControl) {
    if (!control.value) {
      return null;
    }
    const pattern = /^(?:https?:\/\/)?(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&\/=]*)$/g;
    if (!control.value.match(pattern)) {
      return { url: true };
    }
    return null;
  }

  static whiteSpace(control: AbstractControl) {
    if (!control.value || control.value.trim().length === 0) {
      return { required: true };
    }
    return null;
  }

  static email(control: AbstractControl) {
    if (!control.value) {
      return null;
    }
    const pattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (!control.value.match(pattern)) {
      return { email: true };
    }
    return null;
  }

  /**
   * Validates digits and allows optional decimal
   * @param {number} maxDigitsAfterDecimal Maximum number of digits allowed after decimal
   * @returns {(control: AbstractControl) => (any | {numberWihDecimal: boolean})}
   */
  static numberWithOptionalDecimal(maxDigitsAfterDecimal = 2) {
    return function(control: AbstractControl) {
      if (!control.value) return null;
      const pattern = new RegExp(`^[\\d]+(?:\\.[\\d]{1,${maxDigitsAfterDecimal}})?\$`);
      if (!(control.value + '').match(pattern)) {
        return { numberWithDecimal: true };
      }
      return null;
    };
  }

  static number(control: AbstractControl) {
    if (control.value === null || control.value === '') return null;
    const pattern = /^[\d]+$/;
    if (!(control.value + '').match(pattern)) {
      return { number: true };
    }
    return null;
  }
}
