import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Router } from "@angular/router";
import { StorageService } from "./storage.service";
import { Observable, of } from "rxjs";
import { environment } from "../../environments/environment";
import { IResponse } from "../models/response.model";
import { SignUp } from "../models/sign-up.model";

@Injectable({
  providedIn: "root"
})
export class AuthService {
  constructor(
    private http: HttpClient,
    private router: Router,
    private storage: StorageService
  ) {}

  public getToken(): string {
    return this.storage.getItem<string>("token");
  }

  public setToken(token: string) {
    this.storage.setItem("token", token);
  }

  public removeToken() {
    this.storage.removeItem("token");
  }

  public isAuthenticated(): boolean {
    return !!this.getToken();
  }

  public authenticate({ email, password }): Observable<IResponse<any>> {
    return this.http.post<IResponse<any>>(
      `${environment.apiUrl}/auth/login`,
      {
        email,
        password
      }
    );
  }

  public logout() {
    this.router.navigate(["/auth/sign-in"]).then(() => {
      this.removeToken();
      location.reload(true);
      //this.userService.removeCurrentUser();
    });
  }

  verifyUnique(key: "email", value: string): Observable<IResponse<boolean>> {
    return this.http.get<IResponse<boolean>>(
      `${environment.apiUrl}/auth/is-unique`,
      {
        params: { [key]: value }
      }
    );
  }

  signup(data: SignUp): Observable<IResponse<boolean>> {
    return this.http.post<IResponse<boolean>>(
      `${environment.apiUrl}/auth/signup`,
      data
    );
  }

  verifyEmail(token): Observable<IResponse<boolean>> {
    return this.http.post<IResponse<boolean>>(
      `${environment.apiUrl}/auth/verify-email`,
      {
        token
      }
    );
  }
}
