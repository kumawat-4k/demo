import { Component, DoCheck, Input, KeyValueDiffers, OnChanges, OnInit, ViewChild } from '@angular/core';
import { AbstractControl } from '@angular/forms';
import { NgbTooltip } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-validation',
  templateUrl: './validation.component.html',
  styles: []
})
export class ValidationComponent implements OnInit, OnChanges, DoCheck {

  private differ;

  constructor( differs: KeyValueDiffers ) {
    this.differ = differs.find([]).create();
  }

  @ViewChild('t') public tooltip: NgbTooltip;

  @Input()
  control: AbstractControl;

  @Input()
  displayOnSuccess = true;

  @Input()
  messages: { [key: string]: string };

  @Input()
  submitAttempted: boolean;

  showFeedback = false;
  displayedError = '';
  isPending = false;

  ngOnInit() {
  }

  ngOnChanges() {
    this.showFeedback = this.submitAttempted || this.control.dirty;
    this.isPending = this.control.status === 'PENDING';
    for (const error in this.control.errors) {
      this.displayedError = this.messages[error];
      break;
    }
  }

  ngDoCheck() {
    const changes = this.differ.diff(this.control);
    let errorChanges = false;
    let dirtyChanges = false;
    let statusChanges = false;

    if (changes) {
      changes.forEachChangedItem(elt => {
        if (elt.key === 'errors') {
          errorChanges = true;
        }
        if (elt.key === 'dirty') {
          dirtyChanges = true;
        }
        if (elt.key === 'status') {
          statusChanges = true;
        }
      });

    }

    if (errorChanges || dirtyChanges || statusChanges) {
      this.ngOnChanges();
    }

  }

}
