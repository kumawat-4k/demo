export const environment = {
  production: true,
  apiUrl: 'http://localhost:15000/web',
};
