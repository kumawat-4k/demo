import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { HomeComponent } from "./home/home.component";
import { AuthGuard } from "./guards/auth.guard";
import { LoginGuard } from "./guards/login.guard";
import {ProductComponent} from './product/product.component';
import {MyProductComponent} from './my-product/my-product.component'

const routes: Routes = [
  {
    path: "",
    component: HomeComponent
  },
  {
    path: "auth",
    canActivate: [LoginGuard],
    loadChildren: "./auth/auth.module#AuthModule"
  },{
    path:'product',
    canActivate: [AuthGuard],
    component: ProductComponent
  },
  {
    path:'my-product',
    canActivate: [AuthGuard],
    component: MyProductComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
