export interface IResponse<T> {
  success: boolean;
  message?: string;
  data?: T;
  meta?: any;
}

export interface IRecordPage {
  count: number;
  perPage?: number;
}

/*export type IRecordPage<T extends {[key: string]: any}> = {
  [P in keyof T]: T[P];
  count: number;
  perPage?: number;
};*/
