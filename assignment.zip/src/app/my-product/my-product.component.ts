import { Component, OnInit } from "@angular/core";
import { finalize } from "rxjs/operators";
import { ToastrService } from "ngx-toastr";
import { UserService } from "src/app/Services/user.service";

@Component({
  selector: "app-my-product",
  templateUrl: "./my-product.component.html",
  styleUrls: ["./my-product.component.scss"]
})
export class MyProductComponent implements OnInit {
  constructor(
    private toastr: ToastrService,
    private userService: UserService
  ) {}
  submitAttempted = false;
  isBusy = false;
  myProductList: any[];

  ngOnInit() {
    this.MyProductList();
  }

  MyProductList() {
    this.userService
      .getMyProduct()
      .pipe(finalize(() => (this.isBusy = false)))
      .subscribe(response => {
        if (response.success === true) {
          this.myProductList = response.data;
        }
      });
  }
}
