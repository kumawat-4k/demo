const jwt = require('jsonwebtoken');
const {__} = require('../util/common');
const {User} = require('../models/User');

const signToken = function(user) {
    return jwt.sign({id: user._id}, process.env.JWT_SECRET)
};

const verifyToken = function (req, res, next) {

    jwt.verify(req.headers['authorization'], process.env.JWT_SECRET, function (err, decoded) {
        if (err || !decoded || !decoded.id) {
            return res.unauthorized(null, __('Unauthorized'));
        }

        User.findOne({_id: decoded.id, emailVerified: true}, function (err, user) {
            if(err || !user) {
                return res.unauthorized(null, __('Unauthorized'));
            }
            req.user = user;
            res.user = user;
            next();

        });

    });

};

module.exports = {signToken, verifyToken};

