import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { IResponse } from '../models/response.model'
import {environment} from '../../environments/environment'

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private http: HttpClient) { }
  books = [{
    name: 'a',
    type: 'b'
  },
  {
    name: 'b',
    type: 'c'
  },
  {
    name: 'c',
    type: 'd'
  }]
  author = [{
    name: 'Lokesh',
  },
  {
    name: 'Vivek',
  },
  {
    name: 'Rohit',
  }]
  public getBooksList(): Observable<IResponse<any[]>> {
    //return this.http.get<IResponse<any[]>>(`${environment.apiUrl}/booklist`);
    return of({ success: true, message: '', data: this.books });
  }

  public getAuthorList(): Observable<IResponse<any[]>> {
    //return this.http.get<IResponse<any[]>>(`${environment.apiUrl}/author`);
    return of({ success: true, message: '', data: this.author });
  }

}
